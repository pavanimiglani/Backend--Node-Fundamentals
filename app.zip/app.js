//app.js
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const app = express();

//Middleware setup 
app.use(express.urlencoded({extended:true}));

//Session middleware setup with options on seperate lines
app.use(
    session({
        secret: 'your secret key',
        resave: false,
        saveUninitialized: false


    })
);

app.use(passport.initialize());
app.use(passport.session());

require('./passport-config')(passport);


//Protected Route
app.get('/dashboard', ensureAuthenticated,(req,res) => {
    res.send("Welcome, ${req,user.username}! This is a protected dashboard.");

});

// Define a login route
app.get('/login', (req, res) => {
    res.send('Login Page');
});


//Define a POST route for handling login credentials
app.post('/login', passport.authenticate('local',{
    successRedirect:'/dashboard',
    failureRedirect: '/login',

})); 

//Middleware to check if the user is authenticated 
function ensureAuthentication(req,res,next) {
    if (req.isAuthenticated()) {
        return next();

    }
    res.redirect('/login');
} 

// Include and use the route files
const dashboardRoute = require('./dashboardroute');
const loginRoute = require('./Loginroute');

app.use('/', dashboardRoute);
app.use('/', loginRoute);

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});



