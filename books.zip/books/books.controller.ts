import { Controller, Get, Post, Put, Delete, Body, Param } from '@nestjs/common';
import { Book } from './books.entity'; 
import { BooksService } from './books.service'; 

@Controller('books')
export class BooksController {
  constructor(private readonly booksService: BooksService) {}

  @Get()
  getAllBooks(): Book[] {
    return this.booksService.getAllBooks();
  }

  

  @Post()
  createBook(@Body() book: Book): void {
    this.booksService.createBook(book);
  }

}

