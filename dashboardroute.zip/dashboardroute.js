// dashboard.js

const express = require('express');
const ensureAuthenticated = require('./middleware/authMiddleware'); // Import the middleware function

const router = express.Router();

router.get('/dashboard', ensureAuthenticated, (req, res) => {
  res.send(`Welcome, ${req.user.username}! This is a protected dashboard.`);
});

module.exports = router;
